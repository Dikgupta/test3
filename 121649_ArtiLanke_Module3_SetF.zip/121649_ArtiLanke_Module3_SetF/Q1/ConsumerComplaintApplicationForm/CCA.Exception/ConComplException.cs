﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CCA.Exception
{
    public class ConComplException : ApplicationException
    {
           // default constructor 
        public ConComplException() 
           : base()
        { }

        //parameterized constructor
        public ConComplException(string message)
            : base(message)
        { }
    }
}
