﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CCA.Entity;
using CCA.Exception;
using System.Data.SqlClient;
using CCA.BL;

namespace ConsumerComplaintApplication
{
    public partial class ConsumerComplaint : Form
    {
        ConCompValidation validationObj = new ConCompValidation();

        public ConsumerComplaint()
        {
            InitializeComponent();
        }

        private void btn_VerifyEmailID_Click(object sender, EventArgs e)
        {
            string EID = textBox1.Text;
            bool validEID = false;
            if (validationObj.GetConsumerEID(EID))
                validEID = true;
            if (validEID)
                ;
            else
                MessageBox.Show("You are not registered user!!Please register & raise complaint.");
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void btn_Register_Click(object sender, EventArgs e)
        {
           
        }

    }
}