﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using CCA.Entity;
using CCA.Exception;
using System.Data.SqlClient;
using System.Configuration;

namespace CCA.DAL
{
    public class ConComplOperation
    {
         SqlConnection connection;
        SqlDataReader reader;

        public ConComplOperation()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ConsCompConn"].ConnectionString;
            connection = new SqlConnection(connectionString);
        }
         public bool AddSalesmanRecord(ConsumerComplaint conCompObj)
        {
            try
            {
                bool compAdded = false;
                SqlCommand cmdAdd = new SqlCommand("AddConsCompl_121649", connection);
                cmdAdd.CommandType = CommandType.StoredProcedure;
                cmdAdd.Parameters.AddWithValue("@ConsumerEID", conCompObj.ConsumerEID);
                cmdAdd.Parameters.AddWithValue("@Category", conCompObj.Category);
                cmdAdd.Parameters.AddWithValue("@ProductName", conCompObj.ProductName);
                cmdAdd.Parameters.AddWithValue("@DateofPurchase", conCompObj.DoP);
                cmdAdd.Parameters.AddWithValue("@DealerDetails", conCompObj.DealerDetails);
                cmdAdd.Parameters.AddWithValue("@ProductValue", conCompObj.ProductValue);
                cmdAdd.Parameters.AddWithValue("@City", conCompObj.city);
                cmdAdd.Parameters.AddWithValue("@ComplaintDetails", conCompObj.complaintDetails);

                connection.Open();
                int result = cmdAdd.ExecuteNonQuery();
                if (result > 0)
                    compAdded = true;
                return compAdded;
            }
            catch (ConComplException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }
        public bool GetConsumerID(string consumerEID)
        {
            bool consEID = false;
            SqlCommand cmdGetConsumerID = new SqlCommand("RetrieveConsID_121649", connection);
            cmdGetConsumerID.CommandType = CommandType.StoredProcedure;
            cmdGetConsumerID.Parameters.AddWithValue("@ConsumerEID", consumerEID);
            if (connection.State == ConnectionState.Closed)
                connection.Open();
           int result = cmdGetConsumerID.ExecuteNonQuery();
                if (result > 0)
                    consEID= true;
                return consEID;          
        }
    }
}