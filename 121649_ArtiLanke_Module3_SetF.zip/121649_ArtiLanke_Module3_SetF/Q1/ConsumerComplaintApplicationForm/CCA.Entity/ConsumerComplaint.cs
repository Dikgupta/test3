﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CCA.Entity
{
    public class ConsumerComplaint
    {
        // Property to retrieve Consumer email ID
        public string ConsumerEID { get; set; }

        // Property to store category 
        public string Category { get; set; }

        // Property to store Product name
        public string ProductName { get; set; }


        // Property to store Date of purchase
        public DateTime DoP { get; set; }


        // Property to store Dealer Details
        public string DealerDetails { get; set; }


        // Property to store Product Value
        public int ProductValue { get; set; }


        // Property to store city
        public string city { get; set; }


        // Property to store Complaint Details
        public string complaintDetails { get; set; }
    }
}
