﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CCA.Entity;
using CCA.Exception;
using CCA.DAL;

namespace CCA.BL
{
    public class ConCompValidation
    {
       ConComplOperation operationobj = new ConComplOperation();

        public bool ValidateComplaintDetails(ConsumerComplaint complObj)
        {
            bool validComplaint = true;
            StringBuilder sb = new StringBuilder();
            if (complObj.Category == " ")
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Category is required.");
            }
            else if (complObj.Category.ToLower() != "Domestic" && complObj.Category.ToLower() != "Commercial" && complObj.Category.ToLower() != "Educational" && complObj.Category.ToLower() != "Medicine" && complObj.Category.ToLower() != "Other")
            {
                sb.Append("Invalid category.\n");
                validComplaint = false;
            }


            if (complObj.ProductName.Length == 0)
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Product Name is required.");
            }
            if (complObj.DoP.ToString().Length == 0)
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Date of purchase is required.");
            }
            else if (complObj.DoP> DateTime.Today)
            {
                sb.Append("Date of purchase should be less than or equal to current date\n");
                validComplaint = false;
            }



            if (complObj.DealerDetails.Length == 0)
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Dealer Details are required.");
            }
            else if (complObj.DealerDetails.Length >200)
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Dealer Details are exceeding 200 characters.");
            }

            if ( complObj.ProductValue.ToString().Length == 0)
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Product value is required.");
            }

            if (complObj.city.Length == 0)
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "City is required.");
            }

            if (complObj.complaintDetails.Length == 0)
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Complaint detail are required.");
            }
          
            if (validComplaint == false)
                throw new ConComplException(sb.ToString());
            return validComplaint;
        }

        public bool AddComplaintRecord(ConsumerComplaint complObj)
        {
            bool complAdded = false;
            if (ValidateComplaintDetails(complObj))
                complAdded = operationobj.AddSalesmanRecord(complObj);
            return complAdded;
        }

        public bool GetConsumerEID(string consEID)
        {

            bool result = operationobj.GetConsumerID(consEID);
            return result;
        }
    }
}
